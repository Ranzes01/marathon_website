import { useEffect, useState } from "react";

interface HeroSectionProps {
  title: string;
  subtitle: string;
  image: string;
}

export default function HeroSection({ title, subtitle, image }: HeroSectionProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden">
      {/* Imagen de fondo */}
      <img
        src={image}
        alt="Hero Background"
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Gradiente oscuro cinematográfico */}
      <div className="absolute inset-0 cinematic-gradient" />

      {/* Contenido */}
      <div
        className={`relative z-10 text-center px-4 md:px-8 transition-all duration-1000 transform ${
          isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <h1 className="font-serif-display text-4xl md:text-6xl lg:text-7xl text-[#f4d06f] mb-6 text-glow uppercase tracking-widest">
          {title}
        </h1>
        <div className="w-32 h-1 golden-separator mx-auto mb-8" />
        <h2 className="font-body text-xl md:text-2xl lg:text-3xl text-[#e0e0e0] text-glow-subtle tracking-wide">
          {subtitle}
        </h2>
      </div>

      {/* Indicador de scroll */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 animate-bounce">
        <svg
          className="w-6 h-6 text-[#f4d06f]"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </div>
    </div>
  );
}
