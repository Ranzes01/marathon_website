import { Story } from '@/lib/historiesData';
import QuizComponent from '@/components/QuizComponent';
import { useState } from 'react';

interface StoryPageProps {
  story: Story;
  onNext?: () => void;
  onPrev?: () => void;
  onHome?: () => void;
  currentIndex?: number;
  totalStories?: number;
}

export default function StoryPage({ 
  story, 
  onNext, 
  onPrev, 
  onHome, 
  currentIndex = 0, 
  totalStories = 10 
}: StoryPageProps) {
  const [activeTab, setActiveTab] = useState<'story' | 'quiz'>('story');

  const sectionEmojis = ['🏛️', '⚔️', '👑', '🗡️', '🔥'];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div className="relative h-96 overflow-hidden">
        <img
          src={story.heroImage}
          alt={story.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black" />
        
        {/* Botón Volver al Inicio - Esquina Superior */}
        {onHome && (
          <button
            onClick={onHome}
            className="absolute top-4 right-4 bg-amber-600/80 hover:bg-amber-600 text-white px-4 py-2 rounded-lg transition-all z-10 flex items-center gap-2 font-bold"
          >
            ✕ Inicio
          </button>
        )}
        
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <h1 className="text-5xl font-bold text-amber-400 mb-2">{story.title}</h1>
          <p className="text-xl text-amber-200">{story.year} • {story.location}</p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-amber-900/20 border-b border-amber-700/50 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 flex gap-8">
          <button
            onClick={() => setActiveTab('story')}
            className={`py-4 px-6 font-bold transition-colors ${
              activeTab === 'story'
                ? 'text-amber-400 border-b-2 border-amber-400'
                : 'text-amber-200 hover:text-amber-300'
            }`}
          >
            Historia
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`py-4 px-6 font-bold transition-colors ${
              activeTab === 'quiz'
                ? 'text-amber-400 border-b-2 border-amber-400'
                : 'text-amber-200 hover:text-amber-300'
            }`}
          >
            Quiz
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {activeTab === 'story' ? (
          <div className="space-y-12">
            <p className="text-xl text-amber-100 leading-relaxed italic mb-8">
              {story.description}
            </p>

            {story.sections.map((section, index) => (
              <div
                key={index}
                className={`grid grid-cols-1 ${index % 2 === 0 ? 'md:grid-cols-2' : 'md:grid-cols-2'} gap-8 items-center`}
              >
                <div className={index % 2 === 1 ? 'md:order-2' : ''}>
                  <h2 className="text-3xl font-bold text-amber-400 mb-4">{section.title}</h2>
                  <p className="text-lg text-amber-100 leading-relaxed">{section.content}</p>
                </div>
                <div className="h-96 bg-gradient-to-br from-amber-900/30 to-amber-800/30 rounded-lg border border-amber-700/50 flex items-center justify-center">
                  <div className="text-center text-amber-400">
                    <div className="text-6xl mb-4">{sectionEmojis[index % sectionEmojis.length]}</div>
                    <p className="text-sm">Sección {index + 1}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8">
            <h2 className="text-3xl font-bold text-amber-400 mb-8 text-center">
              Prueba tu conocimiento histórico
            </h2>
            <QuizComponent quizzes={story.quiz} />
          </div>
        )}
      </div>

      {/* Navigation Footer */}
      <div className="bg-amber-900/20 border-t border-amber-700/50 py-8">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center gap-4">
          <button
            onClick={onPrev}
            disabled={currentIndex === 0}
            className="bg-amber-600/20 hover:bg-amber-600/40 disabled:opacity-50 disabled:cursor-not-allowed text-amber-300 border border-amber-600/50 px-6 py-3 rounded-lg transition-all font-bold"
          >
            ← Atrás
          </button>
          
          <div className="text-amber-300 text-sm font-semibold">
            {currentIndex + 1} de {totalStories}
          </div>

          <button
            onClick={onNext}
            disabled={currentIndex === totalStories - 1}
            className="bg-amber-600/20 hover:bg-amber-600/40 disabled:opacity-50 disabled:cursor-not-allowed text-amber-300 border border-amber-600/50 px-6 py-3 rounded-lg transition-all font-bold"
          >
            Siguiente →
          </button>
        </div>
      </div>
    </div>
  );
}
