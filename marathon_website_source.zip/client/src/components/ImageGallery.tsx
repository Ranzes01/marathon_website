import { useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { marathonImages } from "@/lib/images";

interface GalleryImage {
  src: string;
  title: string;
  description: string;
}

const galleryImages: GalleryImage[] = [
  {
    src: marathonImages.cover,
    title: "Campo de Batalla",
    description: "La llanura de Maratón al amanecer, donde miles de hoplitas griegos se enfrentaron al Imperio Persa",
  },
  {
    src: marathonImages.greekHoplites,
    title: "Hoplitas Griegos",
    description: "Guerreros ciudadanos con cascos corintios de bronce, listos para defender su libertad",
  },
  {
    src: marathonImages.battleClash,
    title: "El Choque",
    description: "El momento épico del enfrentamiento entre griegos y persas",
  },
  {
    src: marathonImages.pheidippides,
    title: "Fidípides",
    description: "El corredor que llevó la noticia de la victoria a Atenas",
  },
];

export default function ImageGallery() {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const goToPrevious = () => {
    if (selectedIndex === null) return;
    setSelectedIndex((selectedIndex - 1 + galleryImages.length) % galleryImages.length);
  };

  const goToNext = () => {
    if (selectedIndex === null) return;
    setSelectedIndex((selectedIndex + 1) % galleryImages.length);
  };

  return (
    <section className="relative w-full min-h-screen bg-[#0a0a0c] py-20 px-4 md:px-8 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* Título */}
        <div className="text-center mb-16">
          <h2 className="font-serif-display text-4xl md:text-5xl text-[#f4d06f] mb-4 text-glow">
            GALERÍA CINEMATOGRÁFICA
          </h2>
          <div className="w-32 h-1 golden-separator mx-auto" />
          <p className="font-body text-[#e0e0e0] mt-6 text-lg">
            Explora los momentos más épicos de la batalla
          </p>
        </div>

        {/* Grid de imágenes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className="group cursor-pointer relative overflow-hidden rounded-lg h-64 md:h-72"
              onClick={() => setSelectedIndex(index)}
            >
              <img
                src={image.src}
                alt={image.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <h3 className="font-serif-display text-xl text-[#f4d06f] mb-2">
                  {image.title}
                </h3>
                <p className="font-body text-sm text-[#e0e0e0]">
                  {image.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Modal de imagen ampliada */}
        {selectedIndex !== null && (
          <div
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedIndex(null)}
          >
            <div
              className="relative max-w-4xl w-full"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Imagen */}
              <img
                src={galleryImages[selectedIndex].src}
                alt={galleryImages[selectedIndex].title}
                className="w-full h-auto rounded-lg"
              />

              {/* Información */}
              <div className="mt-6 text-center">
                <h3 className="font-serif-display text-2xl text-[#f4d06f] mb-2">
                  {galleryImages[selectedIndex].title}
                </h3>
                <p className="font-body text-[#e0e0e0]">
                  {galleryImages[selectedIndex].description}
                </p>
              </div>

              {/* Botones de navegación */}
              <button
                onClick={goToPrevious}
                className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-16 text-[#f4d06f] hover:text-[#d4a574] transition-colors"
              >
                <ChevronLeft size={32} />
              </button>

              <button
                onClick={goToNext}
                className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-16 text-[#f4d06f] hover:text-[#d4a574] transition-colors"
              >
                <ChevronRight size={32} />
              </button>

              {/* Botón cerrar */}
              <button
                onClick={() => setSelectedIndex(null)}
                className="absolute top-4 right-4 text-[#f4d06f] hover:text-[#d4a574] transition-colors"
              >
                <X size={32} />
              </button>

              {/* Indicador de página */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-[#f4d06f] font-body text-sm">
                {selectedIndex + 1} / {galleryImages.length}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
