import { Story } from '@/lib/historiesData';
import { useLocation } from 'wouter';
import { Card } from '@/components/ui/card';

interface StoriesGalleryProps {
  stories: Story[];
}

export default function StoriesGallery({ stories }: StoriesGalleryProps) {
  const [, setLocation] = useLocation();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {stories.map((story) => (
        <Card
          key={story.id}
          className="group overflow-hidden bg-amber-900/10 border-amber-700/50 hover:border-amber-500/80 transition-all cursor-pointer h-full"
          onClick={() => setLocation(`/story/${story.id}`)}
        >
          {/* Image Container */}
          <div className="relative h-64 overflow-hidden">
            <img
              src={story.image}
              alt={story.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80" />
          </div>

          {/* Content */}
          <div className="p-6 relative">
            <div className="mb-3">
              <span className="inline-block px-3 py-1 bg-amber-600/30 text-amber-300 text-sm rounded-full border border-amber-500/50">
                {story.year}
              </span>
            </div>
            <h3 className="text-xl font-bold text-amber-400 mb-2 group-hover:text-amber-300 transition-colors">
              {story.title}
            </h3>
            <p className="text-sm text-amber-200 mb-4">{story.location}</p>
            <p className="text-amber-100 text-sm leading-relaxed mb-4 line-clamp-3">
              {story.description}
            </p>
            <button className="w-full py-2 px-4 bg-amber-600/20 hover:bg-amber-600/40 text-amber-300 border border-amber-600/50 rounded-lg transition-all text-sm font-semibold">
              Leer Historia →
            </button>
          </div>
        </Card>
      ))}
    </div>
  );
}
