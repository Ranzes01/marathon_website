import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

interface NavigationBarProps {
  sections: Array<{ id: string; title: string }>;
}

export default function NavigationBar({ sections }: NavigationBarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("cover");
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      // Detectar sección activa
      for (const section of sections) {
        const element = document.getElementById(section.id);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= window.innerHeight / 2 && rect.bottom >= window.innerHeight / 2) {
            setActiveSection(section.id);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [sections]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-black/80 backdrop-blur-md border-b border-[#f4d06f]/20"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex justify-between items-center h-16 md:h-20">
          {/* Logo */}
          <div className="flex-shrink-0">
            <h1 className="font-serif-display text-xl md:text-2xl text-[#f4d06f] cursor-pointer hover:text-[#d4a574] transition-colors">
              MARATÓN
            </h1>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => scrollToSection(section.id)}
                className={`font-body text-sm uppercase tracking-widest transition-all duration-300 ${
                  activeSection === section.id
                    ? "text-[#f4d06f] border-b-2 border-[#f4d06f]"
                    : "text-[#e0e0e0] hover:text-[#f4d06f]"
                }`}
              >
                {section.title}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-[#f4d06f] hover:text-[#d4a574] transition-colors"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden bg-black/95 border-t border-[#f4d06f]/20 py-4 space-y-2">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => scrollToSection(section.id)}
                className={`block w-full text-left px-4 py-3 font-body text-sm uppercase tracking-widest transition-colors ${
                  activeSection === section.id
                    ? "bg-[#f4d06f]/10 text-[#f4d06f] border-l-4 border-[#f4d06f]"
                    : "text-[#e0e0e0] hover:bg-[#f4d06f]/5 hover:text-[#f4d06f]"
                }`}
              >
                {section.title}
              </button>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
