import { useEffect, useRef, useState } from "react";

interface TimelineEvent {
  year: string;
  title: string;
  description: string;
}

const events: TimelineEvent[] = [
  {
    year: "490 a.C.",
    title: "Desembarque Persa",
    description: "La flota persa desembarca en la llanura de Maratón con más de 600 barcos",
  },
  {
    year: "Septiembre",
    title: "Movilización Griega",
    description: "Atenas reúne 10,000 hoplitas y 1,000 aliados de Platea",
  },
  {
    year: "Batalla",
    title: "Choque Épico",
    description: "Los griegos ejecutan la táctica de pinza de Milcíades",
  },
  {
    year: "Victoria",
    title: "Triunfo Histórico",
    description: "6,400 persas muertos vs 192 atenienses caídos",
  },
  {
    year: "Legado",
    title: "Salvación de la Democracia",
    description: "Atenas sobrevive para desarrollar la civilización occidental",
  },
];

export default function Timeline() {
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const scrollProgress = Math.max(0, Math.min(1, 1 - rect.top / window.innerHeight));
      const newIndex = Math.floor(scrollProgress * events.length);
      setActiveIndex(Math.min(newIndex, events.length - 1));
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section
      ref={containerRef}
      className="relative w-full min-h-screen bg-gradient-to-b from-[#0a0a0c] via-[#1a1a1e] to-[#0a0a0c] py-20 px-4 md:px-8 overflow-hidden"
    >
      <div className="max-w-6xl mx-auto">
        {/* Título */}
        <div className="text-center mb-20">
          <h2 className="font-serif-display text-4xl md:text-5xl text-[#f4d06f] mb-4 text-glow">
            CRONOLOGÍA DE LA BATALLA
          </h2>
          <div className="w-32 h-1 golden-separator mx-auto" />
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Línea central */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-[#f4d06f] via-[#d4a574] to-[#8b0000]" />

          {/* Eventos */}
          <div className="space-y-16">
            {events.map((event, index) => (
              <div
                key={index}
                className={`transition-all duration-500 transform ${
                  index <= activeIndex ? "opacity-100 scale-100" : "opacity-50 scale-95"
                }`}
              >
                <div
                  className={`grid grid-cols-1 md:grid-cols-2 gap-8 items-center ${
                    index % 2 === 0 ? "md:grid-cols-[1fr_auto_1fr]" : "md:grid-cols-[1fr_auto_1fr]"
                  }`}
                >
                  {/* Contenido izquierdo/derecho */}
                  <div className={`${index % 2 === 0 ? "md:text-right" : "md:col-start-3 md:text-left"}`}>
                    <h3 className="font-serif-display text-2xl text-[#f4d06f] mb-2">
                      {event.title}
                    </h3>
                    <p className="font-body text-[#e0e0e0] leading-relaxed">
                      {event.description}
                    </p>
                  </div>

                  {/* Punto central */}
                  <div className="hidden md:flex justify-center">
                    <div
                      className={`w-6 h-6 rounded-full border-4 transition-all duration-500 ${
                        index <= activeIndex
                          ? "bg-[#f4d06f] border-[#f4d06f] shadow-lg shadow-[#f4d06f]/50"
                          : "bg-transparent border-[#d4a574]"
                      }`}
                    />
                  </div>

                  {/* Año */}
                  <div className="md:hidden text-center mb-4">
                    <span className="font-serif-display text-lg text-[#d4a574]">
                      {event.year}
                    </span>
                  </div>

                  {/* Año desktop */}
                  <div className="hidden md:block text-center">
                    <span className="font-serif-display text-lg text-[#d4a574]">
                      {event.year}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
