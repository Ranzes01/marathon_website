import { useEffect, useState } from "react";

interface ClosingSectionProps {
  title: string;
  subtitle: string;
  image: string;
}

export default function ClosingSection({ title, subtitle, image }: ClosingSectionProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden">
      {/* Imagen de fondo */}
      <img
        src={image}
        alt="Closing Background"
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Gradiente oscuro cinematográfico */}
      <div className="absolute inset-0 bg-gradient-to-top from-black/95 via-black/70 to-black/40" />

      {/* Contenido */}
      <div
        className={`relative z-10 text-center px-4 md:px-8 max-w-4xl transition-all duration-1000 transform ${
          isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <h1 className="font-serif-display font-italic text-3xl md:text-4xl lg:text-5xl text-[#f4d06f] mb-8 text-glow leading-relaxed italic">
          {title}
        </h1>
        <div className="w-32 h-1 golden-separator mx-auto mb-8" />
        <h2 className="font-body text-xl md:text-2xl text-[#e0e0e0] text-glow-subtle tracking-widest">
          {subtitle}
        </h2>
      </div>

      {/* Partículas de luz flotantes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-[#f4d06f] rounded-full opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${3 + i}s ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) translateX(0px); opacity: 0.3; }
          50% { transform: translateY(-20px) translateX(10px); opacity: 0.8; }
        }
      `}</style>
    </div>
  );
}
