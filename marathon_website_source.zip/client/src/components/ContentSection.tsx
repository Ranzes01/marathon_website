import { useEffect, useRef, useState } from "react";

interface ContentSectionProps {
  title: string;
  content: string;
  image: string;
  reverse?: boolean;
  index: number;
}

export default function ContentSection({
  title,
  content,
  image,
  reverse = false,
  index,
}: ContentSectionProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  const isEven = index % 2 === 0;

  return (
    <div
      ref={ref}
      className="relative w-full min-h-screen flex items-center py-20 px-4 md:px-8 overflow-hidden"
    >
      {/* Imagen de fondo */}
      <img
        src={image}
        alt={title}
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Gradiente cinematográfico */}
      <div
        className={`absolute inset-0 ${
          isEven ? "cinematic-gradient-left" : "cinematic-gradient"
        }`}
      />

      {/* Contenido */}
      <div className="relative z-10 max-w-6xl mx-auto w-full">
        <div
          className={`grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
            reverse ? "lg:grid-cols-2" : ""
          }`}
        >
          {/* Texto */}
          <div
            className={`transition-all duration-1000 transform ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
            } ${reverse ? "lg:order-2" : ""}`}
          >
            <h2 className="font-serif-display text-3xl md:text-4xl lg:text-5xl text-[#f4d06f] mb-6 text-glow leading-tight">
              {title}
            </h2>
            <div className="w-20 h-1 golden-separator mb-8" />
            <p className="font-body text-lg md:text-xl text-[#e0e0e0] text-glow-subtle leading-relaxed">
              {content}
            </p>
          </div>

          {/* Imagen */}
          <div
            className={`transition-all duration-1000 transform ${
              isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
            } ${reverse ? "lg:order-1" : ""}`}
          >
            <div className="relative rounded-lg overflow-hidden shadow-2xl">
              <img
                src={image}
                alt={title}
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
