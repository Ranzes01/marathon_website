import { useState } from 'react';
import { Quiz } from '@/lib/historiesData';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface QuizComponentProps {
  quizzes: Quiz[];
}

export default function QuizComponent({ quizzes }: QuizComponentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);

  const quiz = quizzes[currentQuestion];
  const isCorrect = selectedAnswer === quiz.correctAnswer;

  const handleSelectAnswer = (index: number) => {
    if (!showResult) {
      setSelectedAnswer(index);
    }
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer !== null) {
      setShowResult(true);
      if (isCorrect) {
        setScore(score + 1);
      }
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion + 1 < quizzes.length) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setCompleted(true);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setCompleted(false);
  };

  if (completed) {
    return (
      <Card className="w-full max-w-2xl mx-auto p-8 bg-gradient-to-br from-amber-900/20 to-amber-800/20 border-amber-700/50">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-amber-400 mb-4">¡Quiz Completado!</h2>
          <p className="text-2xl text-amber-300 mb-6">
            Puntuación: <span className="font-bold">{score}/{quizzes.length}</span>
          </p>
          <p className="text-lg text-amber-200 mb-8">
            {score === quizzes.length
              ? '¡Excelente! Eres un verdadero historiador.'
              : score >= quizzes.length * 0.7
              ? 'Muy bien, tienes un buen conocimiento histórico.'
              : 'Buen intento. Lee más sobre esta historia.'}
          </p>
          <Button
            onClick={handleRestart}
            className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-lg"
          >
            Reintentar Quiz
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-2xl mx-auto p-8 bg-gradient-to-br from-amber-900/20 to-amber-800/20 border-amber-700/50">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-amber-400">
            Pregunta {currentQuestion + 1}/{quizzes.length}
          </h3>
          <div className="text-amber-300">
            Puntuación: {score}
          </div>
        </div>
        <div className="w-full bg-amber-900/30 rounded-full h-2">
          <div
            className="bg-amber-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestion + 1) / quizzes.length) * 100}%` }}
          />
        </div>
      </div>

      <h4 className="text-2xl font-bold text-amber-100 mb-6">{quiz.question}</h4>

      <div className="space-y-3 mb-8">
        {quiz.options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleSelectAnswer(index)}
            disabled={showResult}
            className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
              selectedAnswer === index
                ? isCorrect && showResult
                  ? 'bg-green-900/40 border-green-500 text-green-100'
                  : !isCorrect && showResult
                  ? 'bg-red-900/40 border-red-500 text-red-100'
                  : 'bg-amber-700/40 border-amber-500 text-amber-100'
                : showResult && index === quiz.correctAnswer
                ? 'bg-green-900/40 border-green-500 text-green-100'
                : 'bg-amber-900/20 border-amber-700 text-amber-200 hover:bg-amber-800/30'
            }`}
          >
            {option}
          </button>
        ))}
      </div>

      {showResult && (
        <div className={`mb-6 p-4 rounded-lg ${isCorrect ? 'bg-green-900/30 border border-green-500' : 'bg-red-900/30 border border-red-500'}`}>
          <p className={`font-bold mb-2 ${isCorrect ? 'text-green-300' : 'text-red-300'}`}>
            {isCorrect ? '✓ ¡Correcto!' : '✗ Incorrecto'}
          </p>
          <p className="text-amber-100">{quiz.explanation}</p>
        </div>
      )}

      <div className="flex gap-4">
        {!showResult ? (
          <Button
            onClick={handleSubmitAnswer}
            disabled={selectedAnswer === null}
            className="flex-1 bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg disabled:opacity-50"
          >
            Responder
          </Button>
        ) : (
          <Button
            onClick={handleNextQuestion}
            className="flex-1 bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg"
          >
            {currentQuestion + 1 === quizzes.length ? 'Ver Resultados' : 'Siguiente Pregunta'}
          </Button>
        )}
      </div>
    </Card>
  );
}
