import { useEffect, useState } from "react";
import HeroSection from "@/components/HeroSection";
import ContentSection from "@/components/ContentSection";
import ClosingSection from "@/components/ClosingSection";
import NavigationBar from "@/components/NavigationBar";
import Timeline from "@/components/Timeline";
import ImageGallery from "@/components/ImageGallery";
import { marathonSections } from "@/lib/images";

export default function Home() {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrolled = window.scrollY;
      setScrollProgress((scrolled / windowHeight) * 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Preparar datos para la navegación
  const navSections = marathonSections.map((section) => ({
    id: section.id,
    title: section.title.split(" ")[0], // Primer palabra para el nav
  }));

  return (
    <div className="w-full bg-[#0a0a0c] text-[#e0e0e0] overflow-x-hidden">
      {/* Barra de progreso */}
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-[#f4d06f] via-[#d4a574] to-[#8b0000] z-50 transition-all duration-300"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Navegación */}
      <NavigationBar sections={navSections} />

      {/* Contenido */}
      <main className="w-full">
        {marathonSections.map((section, index) => (
          <section key={section.id} id={section.id}>
            {section.type === "hero" && (
              <HeroSection
                title={section.title}
                subtitle={section.subtitle || ""}
                image={section.image}
              />
            )}
            {section.type === "content" && (
              <ContentSection
                title={section.title}
                content={section.content || ""}
                image={section.image}
                reverse={index % 2 === 1}
                index={index}
              />
            )}
            {section.type === "closing" && (
              <ClosingSection
                title={section.title}
                subtitle={section.subtitle || ""}
                image={section.image}
              />
            )}
          </section>
        ))}

        {/* Timeline Interactivo */}
        <Timeline />

        {/* Galería de Imágenes */}
        <ImageGallery />
      </main>

      {/* Footer */}
      <footer className="relative bg-black/80 border-t border-[#f4d06f]/20 py-12 px-4 md:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Sobre */}
            <div>
              <h3 className="font-serif-display text-lg text-[#f4d06f] mb-4">
                LA BATALLA DE MARATÓN
              </h3>
              <p className="font-body text-sm text-[#a0a0a0] leading-relaxed">
                Una experiencia cinematográfica que honra el sacrificio heroico de los guerreros que defendieron la libertad.
              </p>
            </div>

            {/* Enlaces rápidos */}
            <div>
              <h3 className="font-serif-display text-lg text-[#f4d06f] mb-4">
                ENLACES
              </h3>
              <ul className="font-body text-sm space-y-2">
                <li>
                  <a href="#cover" className="text-[#a0a0a0] hover:text-[#f4d06f] transition-colors">
                    Inicio
                  </a>
                </li>
                <li>
                  <a href="#empire" className="text-[#a0a0a0] hover:text-[#f4d06f] transition-colors">
                    Historia
                  </a>
                </li>
                <li>
                  <a href="#closing" className="text-[#a0a0a0] hover:text-[#f4d06f] transition-colors">
                    Legado
                  </a>
                </li>
              </ul>
            </div>

            {/* Información */}
            <div>
              <h3 className="font-serif-display text-lg text-[#f4d06f] mb-4">
                INFORMACIÓN
              </h3>
              <p className="font-body text-sm text-[#a0a0a0]">
                490 a.C. — Llanura de Maratón, Grecia
              </p>
              <p className="font-body text-sm text-[#a0a0a0] mt-2">
                Creado con pasión por la historia épica
              </p>
            </div>
          </div>

          {/* Divisor */}
          <div className="w-full h-px golden-separator mb-8" />

          {/* Copyright */}
          <div className="text-center">
            <p className="font-body text-xs text-[#a0a0a0]">
              © 2026 La Batalla de Maratón. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
