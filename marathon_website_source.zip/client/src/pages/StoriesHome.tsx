import { stories } from '@/lib/historiesData';
import StoriesGallery from '@/components/StoriesGallery';
import HeroCarousel from '@/components/HeroCarousel';

export default function StoriesHome() {
  // Obtener imágenes de todas las historias para el carrusel
  const carouselImages = stories.map(story => story.heroImage);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section con Carrusel */}
      <div className="relative h-96 overflow-hidden">
        <HeroCarousel images={carouselImages} interval={4000} />
        
        {/* Content overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4 z-20">
          <h1 className="text-6xl md:text-7xl font-bold text-amber-400 mb-4 drop-shadow-lg">
            Historias Épicas
          </h1>
          <p className="text-2xl text-amber-200 mb-6 drop-shadow-md">
            Descubre los momentos que cambiaron el mundo
          </p>
          <p className="text-lg text-amber-100 max-w-2xl drop-shadow-md">
            Desde batallas legendarias hasta imperios caídos, explora 10 historias que definen la civilización humana
          </p>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-amber-900/20 border-y border-amber-700/50 py-8">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-3 gap-8 text-center">
          <div>
            <div className="text-4xl font-bold text-amber-400">{stories.length}</div>
            <p className="text-amber-200">Historias</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-amber-400">{stories.reduce((sum, s) => sum + s.quiz.length, 0)}</div>
            <p className="text-amber-200">Preguntas de Quiz</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-amber-400">2000+</div>
            <p className="text-amber-200">Años de Historia</p>
          </div>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="mb-12">
          <h2 className="text-4xl font-bold text-amber-400 mb-4">Explora las Historias</h2>
          <p className="text-amber-200 text-lg">
            Haz clic en cualquier historia para leer los detalles completos y participar en el quiz interactivo
          </p>
        </div>
        <StoriesGallery stories={stories} />
      </div>

      {/* Features Section */}
      <div className="bg-amber-900/10 border-t border-amber-700/50 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-amber-400 mb-12 text-center">¿Qué encontrarás?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-5xl mb-4">📖</div>
              <h3 className="text-2xl font-bold text-amber-400 mb-3">Historias Detalladas</h3>
              <p className="text-amber-100">
                Cada historia cuenta con 5 secciones detalladas que exploran los eventos más importantes y sus consecuencias
              </p>
            </div>
            <div className="text-center">
              <div className="text-5xl mb-4">🎯</div>
              <h3 className="text-2xl font-bold text-amber-400 mb-3">Quiz Interactivo</h3>
              <p className="text-amber-100">
                Prueba tu conocimiento con 5 preguntas por historia. Aprende mientras juegas y obtén tu puntuación final
              </p>
            </div>
            <div className="text-center">
              <div className="text-5xl mb-4">🎬</div>
              <h3 className="text-2xl font-bold text-amber-400 mb-3">Experiencia Cinematográfica</h3>
              <p className="text-amber-100">
                Imágenes épicas y cinematográficas que te transportan a cada momento histórico
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-amber-900/30 to-amber-800/30 border-t border-amber-700/50 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-amber-400 mb-6">
            ¿Listo para explorar la historia?
          </h2>
          <p className="text-xl text-amber-100 mb-8">
            Selecciona cualquier historia arriba para comenzar tu viaje a través del tiempo
          </p>
        </div>
      </div>
    </div>
  );
}
