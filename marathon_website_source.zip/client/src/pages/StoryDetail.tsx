import { useParams, useLocation } from 'wouter';
import { stories } from '@/lib/historiesData';
import StoryPage from '@/components/StoryPage';
import { Button } from '@/components/ui/button';

export default function StoryDetail() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const storyId = params.id;

  const currentIndex = stories.findIndex((s) => s.id === storyId);
  const story = stories[currentIndex];

  if (!story) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
        <h1 className="text-4xl font-bold text-amber-400 mb-4">Historia no encontrada</h1>
        <p className="text-amber-200 mb-8">La historia que buscas no existe</p>
        <Button
          onClick={() => setLocation('/')}
          className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-lg"
        >
          Volver a Historias
        </Button>
      </div>
    );
  }

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setLocation(`/story/${stories[currentIndex + 1].id}`);
      window.scrollTo(0, 0);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setLocation(`/story/${stories[currentIndex - 1].id}`);
      window.scrollTo(0, 0);
    }
  };

  const handleHome = () => {
    setLocation('/');
    window.scrollTo(0, 0);
  };

  return (
    <StoryPage 
      story={story} 
      onNext={handleNext}
      onPrev={handlePrev}
      onHome={handleHome}
      currentIndex={currentIndex}
      totalStories={stories.length}
    />
  );
}
