// Imágenes cinematográficas de la Batalla de Maratón
export const marathonImages = {
  cover: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide1_cover_ff7a8884.jpg",
  persianEmpire: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide2_persian_empire_f3b8ef59.jpg",
  greekHoplites: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide3_greek_hoplites_7f70a0a5.jpg",
  tacticalMap: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide4_tactical_map_0d9af938.jpg",
  battleClash: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide5_battle_clash_178db102.jpg",
  pheidippides: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide6_pheidippides_aabf8c5d.jpg",
  closing: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide8_closing_96d0876d.jpg",
};

export const marathonSections = [
  {
    id: "cover",
    title: "LA BATALLA DE MARATÓN",
    subtitle: "490 a.C. — El día que Grecia desafió al Imperio Persa",
    image: marathonImages.cover,
    type: "hero",
  },
  {
    id: "empire",
    title: "Un Imperio sin igual avanzaba sobre Grecia",
    content: "El Imperio Aqueménida bajo Darío I era la potencia más grande que el mundo antiguo había conocido. Con más de 600 barcos y un ejército estimado entre 25,000 y 100,000 soldados, la flota persa desembarcó en la llanura de Maratón en septiembre del 490 a.C., con una sola misión: someter a Atenas y borrar el recuerdo de la revuelta jónica.",
    image: marathonImages.persianEmpire,
    type: "content",
  },
  {
    id: "defenders",
    title: "10,000 hoplitas entre Atenas y la esclavitud",
    content: "Frente a la marea persa, Atenas reunió apenas 10,000 hoplitas ciudadanos-soldados, más 1,000 aliados de Platea. El estratega Milcíades convenció al consejo de atacar en lugar de esperar. Cada hoplita sabía que no luchaba solo por su ciudad: luchaba por la idea misma de que los hombres libres podían vencer a un ejército de esclavos del rey.",
    image: marathonImages.greekHoplites,
    type: "content",
  },
  {
    id: "tactics",
    title: "Milcíades diseñó una trampa perfecta en el campo de batalla",
    content: "La formación griega fue deliberadamente debilitada en el centro y reforzada en los flancos. Cuando los persas avanzaron, el centro griego cedió lentamente, atrayendo al enemigo hacia una trampa mortal. Los flancos envolvieron al ejército persa en una maniobra de pinza que los aniquiló antes de que pudieran reaccionar. Fue una de las primeras maniobras de envolvimiento documentadas en la historia militar.",
    image: marathonImages.tacticalMap,
    type: "content",
  },
  {
    id: "clash",
    title: "En pocas horas, el destino del mundo occidental se decidió",
    content: "La batalla duró apenas unas horas. Los griegos corrieron hacia las líneas persas para minimizar el tiempo bajo la lluvia de flechas enemigas. El choque fue brutal y decisivo. Al final del día, 6,400 persas yacían muertos en la llanura de Maratón, frente a apenas 192 atenienses caídos. El ejército persa huyó hacia sus barcos.",
    image: marathonImages.battleClash,
    type: "content",
  },
  {
    id: "pheidippides",
    title: "Fidípides corrió 42 km para anunciar la victoria — y murió al llegar",
    content: "Según la leyenda, el mensajero Fidípides corrió desde Maratón hasta Atenas —aproximadamente 42 kilómetros— para anunciar la victoria griega. Al llegar, pronunció las palabras \"¡Nenikékamen!\" (¡Hemos vencido!) y cayó muerto de agotamiento. Este acto de sacrificio y devoción inspiró siglos después la creación del maratón olímpico moderno en los Juegos de Atenas de 1896.",
    image: marathonImages.pheidippides,
    type: "content",
  },
  {
    id: "legacy",
    title: "Maratón salvó la democracia antes de que pudiera florecer",
    content: "La victoria en Maratón tuvo consecuencias que se extienden hasta hoy. Atenas sobrevivió para desarrollar la democracia, la filosofía, el teatro y las artes durante el Siglo de Oro de Pericles. Sin Maratón, no habría habido Sócrates, Platón, Aristóteles, ni los fundamentos intelectuales sobre los que se construyó la civilización occidental. Los 192 atenienses caídos fueron enterrados en el Tumulus de Maratón, honrados como héroes para siempre.",
    image: marathonImages.cover,
    type: "content",
  },
  {
    id: "closing",
    title: "\"Los que murieron en Maratón son los más valientes de todos los hombres que hemos conocido.\"",
    subtitle: "— Heródoto, Historias, Libro VI",
    image: marathonImages.closing,
    type: "closing",
  },
];
