export interface Story {
  id: string;
  title: string;
  shortTitle: string;
  year: string;
  location: string;
  description: string;
  image: string;
  heroImage: string;
  sections: Section[];
  quiz: Quiz[];
}

export interface Section {
  title: string;
  content: string;
}

export interface Quiz {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const stories: Story[] = [
  {
    id: "marathon",
    title: "LA BATALLA DE MARATÓN",
    shortTitle: "Maratón",
    year: "490 a.C.",
    location: "Llanura de Maratón, Grecia",
    description: "El día que Grecia desafió al Imperio Persa",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide1_cover_ff7a8884.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/slide1_cover_ff7a8884.jpg",
    sections: [
      {
        title: "Un Imperio sin igual avanzaba sobre Grecia",
        content: "El Imperio Aqueménida bajo Darío I era la potencia más grande que el mundo antiguo había conocido. Con más de 600 barcos y un ejército estimado entre 25,000 y 100,000 soldados, la flota persa desembarcó en la llanura de Maratón en septiembre del 490 a.C., con una sola misión: someter a Atenas y borrar el recuerdo de la revuelta jónica.",
      },
      {
        title: "10,000 hoplitas entre Atenas y la esclavitud",
        content: "Frente a la marea persa, Atenas reunió apenas 10,000 hoplitas ciudadanos-soldados, más 1,000 aliados de Platea. El estratega Milcíades convenció al consejo de atacar en lugar de esperar. Cada hoplita sabía que no luchaba solo por su ciudad: luchaba por la idea misma de que los hombres libres podían vencer a un ejército de esclavos del rey.",
      },
      {
        title: "Milcíades diseñó una trampa perfecta en el campo de batalla",
        content: "La formación griega fue deliberadamente debilitada en el centro y reforzada en los flancos. Cuando los persas avanzaron, el centro griego cedió lentamente, atrayendo al enemigo hacia una trampa mortal. Los flancos envolvieron al ejército persa en una maniobra de pinza que los aniquiló antes de que pudieran reaccionar.",
      },
      {
        title: "En pocas horas, el destino del mundo occidental se decidió",
        content: "La batalla duró apenas unas horas. Los griegos corrieron hacia las líneas persas para minimizar el tiempo bajo la lluvia de flechas enemigas. El choque fue brutal y decisivo. Al final del día, 6,400 persas yacían muertos en la llanura de Maratón, frente a apenas 192 atenienses caídos.",
      },
      {
        title: "Fidípides corrió 42 km para anunciar la victoria",
        content: "Según la leyenda, el mensajero Fidípides corrió desde Maratón hasta Atenas —aproximadamente 42 kilómetros— para anunciar la victoria griega. Al llegar, pronunció las palabras '¡Nenikékamen!' (¡Hemos vencido!) y cayó muerto de agotamiento. Este acto de sacrificio inspiró siglos después la creación del maratón olímpico moderno.",
      },
    ],
    quiz: [
      {
        question: "¿En qué año ocurrió la Batalla de Maratón?",
        options: ["500 a.C.", "490 a.C.", "480 a.C.", "470 a.C."],
        correctAnswer: 1,
        explanation: "La Batalla de Maratón tuvo lugar en el 490 a.C., cuando el Imperio Persa intentó conquistar Atenas.",
      },
      {
        question: "¿Cuántos hoplitas griegos participaron en la batalla?",
        options: ["5,000", "10,000", "15,000", "20,000"],
        correctAnswer: 1,
        explanation: "Atenas reunió aproximadamente 10,000 hoplitas ciudadanos-soldados, más 1,000 aliados de Platea.",
      },
      {
        question: "¿Quién fue el estratega que diseñó la táctica de pinza?",
        options: ["Leónidas", "Milcíades", "Temístocles", "Pericles"],
        correctAnswer: 1,
        explanation: "Milcíades fue el estratega ateniense que diseñó la famosa maniobra de pinza que envolvió al ejército persa.",
      },
      {
        question: "¿Cuántos persas murieron en la batalla?",
        options: ["2,000", "4,000", "6,400", "10,000"],
        correctAnswer: 2,
        explanation: "Se estima que 6,400 soldados persas murieron en la Batalla de Maratón.",
      },
      {
        question: "¿Cuántos kilómetros corrió Fidípides para anunciar la victoria?",
        options: ["30 km", "35 km", "42 km", "50 km"],
        correctAnswer: 2,
        explanation: "Fidípides corrió aproximadamente 42 kilómetros desde Maratón hasta Atenas, distancia que inspiró el maratón moderno.",
      },
    ],
  },
  {
    id: "nero",
    title: "NERÓN — DÉSPOTA Y ARTISTA",
    shortTitle: "Nerón",
    year: "37-68 d.C.",
    location: "Imperio Romano",
    description: "El emperador que combinaba la crueldad con la pasión por el arte",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/nero-hero_f778c7e6.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/nero-hero_f778c7e6.jpg",
    sections: [
      {
        title: "El Ascenso de un Tirano",
        content: "Nerón nació el 15 de diciembre del 37 d.C. como Lucio Domicio Enobarbo. Su madre, Agripina la Menor, lo adoptó como hijo de Claudio para asegurar su sucesión. A los 16 años, Nerón se convirtió en emperador del Imperio Romano, el más joven en ese momento.",
      },
      {
        title: "La Sombra de Séneca",
        content: "Durante sus primeros años, Nerón fue guiado por el filósofo Séneca, quien intentó inculcarle principios de justicia y moderación. Sin embargo, la influencia de Séneca disminuyó gradualmente, y Nerón comenzó a revelar su verdadera naturaleza: ambicioso, cruel e impulsivo.",
      },
      {
        title: "Crímenes y Paranoia",
        content: "Nerón ordenó la muerte de su propia madre, Agripina, en el 59 d.C. Luego mandó ejecutar a su maestro Séneca en el 65 d.C. Su reinado fue marcado por purgas, ejecuciones arbitrarias y una paranoia creciente hacia cualquiera que pudiera amenazar su poder.",
      },
      {
        title: "El Incendio de Roma",
        content: "En el 64 d.C., un incendio devastador destruyó gran parte de Roma. Aunque la culpa de Nerón es debatida por historiadores, la leyenda lo retrata tocando la lira mientras la ciudad ardía. Después del incendio, Nerón construyó la Domus Aurea, un palacio monumental que consumió enormes recursos.",
      },
      {
        title: "El Artista Tirano",
        content: "A pesar de sus crímenes, Nerón era genuinamente apasionado por la música, el teatro y la poesía. Participaba en competiciones artísticas, aunque sus jueces siempre lo declaraban ganador por miedo. Su legado es el de un hombre dividido entre el genio creativo y la maldad despótica.",
      },
    ],
    quiz: [
      {
        question: "¿En qué año nació Nerón?",
        options: ["35 d.C.", "37 d.C.", "40 d.C.", "42 d.C."],
        correctAnswer: 1,
        explanation: "Nerón nació el 15 de diciembre del 37 d.C.",
      },
      {
        question: "¿A qué edad se convirtió Nerón en emperador?",
        options: ["14 años", "16 años", "18 años", "20 años"],
        correctAnswer: 1,
        explanation: "Nerón se convirtió en emperador a los 16 años, siendo el emperador más joven de Roma en ese momento.",
      },
      {
        question: "¿Quién fue el filósofo que guió a Nerón en sus primeros años?",
        options: ["Cicerón", "Séneca", "Plinio", "Tácito"],
        correctAnswer: 1,
        explanation: "Séneca fue el filósofo que intentó guiar a Nerón hacia la justicia y moderación.",
      },
      {
        question: "¿En qué año ocurrió el famoso incendio de Roma?",
        options: ["60 d.C.", "62 d.C.", "64 d.C.", "66 d.C."],
        correctAnswer: 2,
        explanation: "El incendio de Roma ocurrió en el 64 d.C., durante el reinado de Nerón.",
      },
      {
        question: "¿Cuál fue el nombre del palacio monumental que Nerón construyó después del incendio?",
        options: ["Palacio Palatino", "Domus Aurea", "Villa Adriana", "Castillo Adriano"],
        correctAnswer: 1,
        explanation: "La Domus Aurea (Casa Dorada) fue el palacio monumental construido por Nerón después del incendio de Roma.",
      },
    ],
  },
  {
    id: "arthur",
    title: "EL REY ARTURO — EL MITO DE CAMELOT",
    shortTitle: "Rey Arturo",
    year: "Siglo VI (Legendario)",
    location: "Gran Bretaña",
    description: "La leyenda del rey que unificó Britania y buscó el Santo Grial",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/arthur-hero_7ba06b09.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/arthur-hero_7ba06b09.jpg",
    sections: [
      {
        title: "El Nacimiento de un Héroe",
        content: "Según la leyenda, Arturo fue hijo de Uther Pendragon y la reina Igerna. Fue criado en secreto por el mago Merlín y educado para ser el futuro rey de Britania. Su infancia estuvo rodeada de magia y misterio, preparándolo para el destino que lo esperaba.",
      },
      {
        title: "La Espada en la Piedra",
        content: "Arturo demostró su derecho al trono al extraer la legendaria espada Excalibur de una piedra. Este acto mágico lo legitimó como rey de Britania. Con Excalibur en mano, Arturo se convirtió en un guerrero invencible y un símbolo de esperanza para su pueblo.",
      },
      {
        title: "Camelot y la Mesa Redonda",
        content: "Arturo estableció su corte en el legendario castillo de Camelot, donde reunía a los más grandes caballeros de Britania alrededor de la Mesa Redonda. Esta mesa sin cabecera simbolizaba la igualdad entre los caballeros y la búsqueda común del bien y la justicia.",
      },
      {
        title: "Los Caballeros de la Leyenda",
        content: "Entre los caballeros más famosos estaban Lancelot, Gawain, Bedivere y Percival. Cada uno tenía sus propias aventuras y virtudes. La traición de Lancelot con la reina Ginebra fue el evento que comenzó la caída del reino de Arturo.",
      },
      {
        title: "La Caída de Camelot",
        content: "El descubrimiento del romance entre Lancelot y Ginebra causó una guerra civil en Camelot. Arturo fue mortalmente herido en la batalla final contra su hijo ilegítimo Mordred. Según la leyenda, fue llevado a la isla mística de Avalon, donde se dice que descansa esperando el momento de regresar.",
      },
    ],
    quiz: [
      {
        question: "¿Quién fue el mago que crió a Arturo?",
        options: ["Merlín", "Morgana", "Nimue", "Viviana"],
        correctAnswer: 0,
        explanation: "Merlín fue el mago que crió a Arturo en secreto y lo preparó para ser rey.",
      },
      {
        question: "¿Cuál es el nombre de la legendaria espada de Arturo?",
        options: ["Caliburn", "Excalibur", "Kusanagi", "Durandal"],
        correctAnswer: 1,
        explanation: "Excalibur es la legendaria espada de Arturo, que extrajo de una piedra para demostrar su derecho al trono.",
      },
      {
        question: "¿Cuál era el propósito de la Mesa Redonda?",
        options: ["Almacenar tesoros", "Simbolizar igualdad entre caballeros", "Servir como trono", "Guardar mapas"],
        correctAnswer: 1,
        explanation: "La Mesa Redonda simbolizaba la igualdad entre los caballeros y su búsqueda común del bien y la justicia.",
      },
      {
        question: "¿Cuál fue la traición que llevó a la caída de Camelot?",
        options: ["Mordred conspiró contra Arturo", "Lancelot se enamoró de Ginebra", "Merlín lo abandonó", "Los sajones invadieron"],
        correctAnswer: 1,
        explanation: "El romance entre Lancelot y la reina Ginebra fue descubierto, causando una guerra civil que llevó a la caída de Camelot.",
      },
      {
        question: "¿A dónde fue llevado Arturo después de su muerte?",
        options: ["Al cielo", "A la isla de Avalon", "Al inframundo", "A Camelot"],
        correctAnswer: 1,
        explanation: "Según la leyenda, Arturo fue llevado a la isla mística de Avalon, donde descansa esperando regresar.",
      },
    ],
  },
  {
    id: "sparta",
    title: "ESPARTA — CIUDAD DE GUERREROS",
    shortTitle: "Esparta",
    year: "Siglo VIII - V a.C.",
    location: "Peloponeso, Grecia",
    description: "La sociedad militar más disciplinada de la antigüedad",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/sparta-hero_62ac3923.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/sparta-hero_62ac3923.jpg",
    sections: [
      {
        title: "El Sistema de Licurgo",
        content: "Licurgo fue el legislador que transformó Esparta en una sociedad militar. Sus reformas establecieron un sistema único donde todo se subordinaba al ejército. La educación, la economía y la política estaban diseñadas para producir guerreros perfectos.",
      },
      {
        title: "La Educación Espartana",
        content: "Los niños espartanos eran separados de sus madres a los 7 años para recibir entrenamiento militar. Aprendían a luchar, a obedecer órdenes sin cuestionar y a valorar la muerte en batalla más que la vida en paz. Este sistema creó una élite de guerreros sin igual.",
      },
      {
        title: "Los Hoplitas Espartanos",
        content: "Los hoplitas espartanos eran la infantería más temida de Grecia. Formaban la falange, una formación táctica casi impenetrable. Su disciplina, coordinación y valentía los hacían prácticamente invencibles en el campo de batalla.",
      },
      {
        title: "Las Termópilas: El Último Acto",
        content: "En el 480 a.C., el rey Leónidas lideró 300 hoplitas espartanos en la Batalla de las Termópilas contra el ejército persa. Aunque fueron derrotados, su resistencia legendaria inspiró a toda Grecia y demostró que la disciplina y el valor podían desafiar incluso a un imperio.",
      },
      {
        title: "El Legado de Esparta",
        content: "Aunque Esparta finalmente fue superada por Atenas y otras ciudades-estado, su legado perduró. Su modelo de disciplina militar y sacrificio personal influyó en civilizaciones posteriores y sigue siendo un símbolo de valor y dedicación.",
      },
    ],
    quiz: [
      {
        question: "¿Quién fue el legislador que transformó Esparta?",
        options: ["Leónidas", "Licurgo", "Temístocles", "Pericles"],
        correctAnswer: 1,
        explanation: "Licurgo fue el legislador que implementó las reformas que transformaron Esparta en una sociedad militar.",
      },
      {
        question: "¿A qué edad comenzaba el entrenamiento militar en Esparta?",
        options: ["5 años", "7 años", "10 años", "12 años"],
        correctAnswer: 1,
        explanation: "Los niños espartanos eran separados de sus madres a los 7 años para comenzar su entrenamiento militar.",
      },
      {
        question: "¿Cuál era la formación táctica principal de los hoplitas espartanos?",
        options: ["Columna", "Falange", "Línea dispersa", "Círculo"],
        correctAnswer: 1,
        explanation: "La falange era la formación táctica principal de los hoplitas espartanos, casi impenetrable en batalla.",
      },
      {
        question: "¿En qué año ocurrió la Batalla de las Termópilas?",
        options: ["490 a.C.", "480 a.C.", "470 a.C.", "460 a.C."],
        correctAnswer: 1,
        explanation: "La Batalla de las Termópilas ocurrió en el 480 a.C., cuando Leónidas y 300 espartanos enfrentaron al ejército persa.",
      },
      {
        question: "¿Cuántos hoplitas espartanos lideró Leónidas en las Termópilas?",
        options: ["100", "200", "300", "500"],
        correctAnswer: 2,
        explanation: "Leónidas lideró 300 hoplitas espartanos en la legendaria Batalla de las Termópilas.",
      },
    ],
  },
  {
    id: "waterloo",
    title: "LA BATALLA DE WATERLOO — EL FIN DE NAPOLEÓN",
    shortTitle: "Waterloo",
    year: "18 de junio de 1815",
    location: "Bélgica",
    description: "La batalla que marcó el final de la era napoleónica",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/waterloo-hero_cd4efc68.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/waterloo-hero_cd4efc68.jpg",
    sections: [
      {
        title: "El Retorno de Napoleón",
        content: "Después de ser exiliado a Elba, Napoleón escapó y regresó a Francia en 1815. Sus antiguos soldados lo aclamaron, y rápidamente reunió un ejército. Las potencias europeas, temerosas de su regreso, se aliaron para derrotarlo definitivamente.",
      },
      {
        title: "Los Cien Días",
        content: "El período entre el regreso de Napoleón y la Batalla de Waterloo se conoce como los Cien Días. Durante este tiempo, Napoleón intentó consolidar su poder y prepararse para la batalla final contra las fuerzas aliadas.",
      },
      {
        title: "El Enfrentamiento Final",
        content: "El 18 de junio de 1815, Napoleón enfrentó a un ejército aliado liderado por el Duque de Wellington y el Mariscal Blücher. La batalla fue feroz y decisiva. A pesar de los esfuerzos de Napoleón, sus fuerzas fueron derrotadas.",
      },
      {
        title: "La Derrota Definitiva",
        content: "La derrota en Waterloo fue total y definitiva. Napoleón fue capturado y exiliado a la isla de Santa Elena, una remota isla en el Atlántico Sur, donde pasaría el resto de sus días. Su imperio se derrumbó, y Europa entró en una nueva era.",
      },
      {
        title: "El Legado de Waterloo",
        content: "La Batalla de Waterloo marcó el fin de la era napoleónica y el comienzo de la era de la restauración monárquica en Europa. Sin embargo, las ideas de Napoleón sobre el derecho civil, la educación y la administración continuaron influyendo en Europa durante siglos.",
      },
    ],
    quiz: [
      {
        question: "¿En qué fecha ocurrió la Batalla de Waterloo?",
        options: ["15 de junio de 1815", "18 de junio de 1815", "21 de junio de 1815", "25 de junio de 1815"],
        correctAnswer: 1,
        explanation: "La Batalla de Waterloo ocurrió el 18 de junio de 1815.",
      },
      {
        question: "¿Dónde fue exiliado Napoleón después de Waterloo?",
        options: ["Córcega", "Elba", "Santa Elena", "Malta"],
        correctAnswer: 2,
        explanation: "Napoleón fue exiliado a la isla de Santa Elena, una remota isla en el Atlántico Sur.",
      },
      {
        question: "¿Quién lideró las fuerzas aliadas en Waterloo?",
        options: ["Mariscal Blücher", "Duque de Wellington", "Ambos", "Zar Alejandro"],
        correctAnswer: 2,
        explanation: "Tanto el Duque de Wellington como el Mariscal Blücher lideraron las fuerzas aliadas en Waterloo.",
      },
      {
        question: "¿Cuántos días duraron los Cien Días?",
        options: ["90 días", "100 días", "110 días", "120 días"],
        correctAnswer: 1,
        explanation: "Los Cien Días fue el período entre el regreso de Napoleón y la Batalla de Waterloo.",
      },
      {
        question: "¿Cuál fue el resultado de la Batalla de Waterloo?",
        options: ["Victoria de Napoleón", "Derrota de Napoleón", "Empate", "Retirada de ambos ejércitos"],
        correctAnswer: 1,
        explanation: "La Batalla de Waterloo resultó en una derrota definitiva de Napoleón y sus fuerzas.",
      },
    ],
  },
  {
    id: "buddha",
    title: "BUDA — EL HOMBRE QUE ILUMINÓ EL MUNDO",
    shortTitle: "Buda",
    year: "563-483 a.C.",
    location: "Nepal e India",
    description: "El príncipe que renunció al lujo para encontrar la verdad",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/buddha-hero_0beecb54.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/buddha-hero_0beecb54.jpg",
    sections: [
      {
        title: "El Príncipe Siddhartha",
        content: "Siddhartha Gautama nació alrededor del 563 a.C. en el reino de Shakya, en lo que hoy es Nepal. Era hijo del rey Suddhodana y fue criado en un palacio lujoso, protegido de todo sufrimiento. Su padre esperaba que se convirtiera en un gran guerrero y gobernante.",
      },
      {
        title: "El Despertar al Sufrimiento",
        content: "A los 29 años, Siddhartha abandonó el palacio y se encontró con la realidad del sufrimiento humano: la enfermedad, la vejez y la muerte. Profundamente conmovido, decidió renunciar a su vida de lujo para buscar la verdad y encontrar una solución al sufrimiento.",
      },
      {
        title: "La Búsqueda del Camino Medio",
        content: "Siddhartha pasó años como asceta, practicando ayunos extremos y meditación. Finalmente, comprendió que ni el lujo extremo ni la privación extrema llevan a la iluminación. El verdadero camino era el 'Camino Medio', el equilibrio entre los extremos.",
      },
      {
        title: "La Iluminación bajo el Árbol Bodhi",
        content: "A los 35 años, Siddhartha se sentó bajo el árbol Bodhi en Gaya para meditar. Después de 49 días de meditación profunda, alcanzó la iluminación o 'Bodhi'. En ese momento, comprendió las Cuatro Nobles Verdades y se convirtió en Buda, el 'Iluminado'.",
      },
      {
        title: "El Legado del Buda",
        content: "Buda pasó los siguientes 45 años viajando y enseñando. Sus enseñanzas sobre el sufrimiento, la compasión y el camino hacia la liberación se extendieron por toda Asia. Hoy, más de 500 millones de personas practican el budismo, haciendo de Buda una de las figuras más influyentes de la historia.",
      },
    ],
    quiz: [
      {
        question: "¿En qué año nació Siddhartha Gautama (Buda)?",
        options: ["600 a.C.", "563 a.C.", "500 a.C.", "450 a.C."],
        correctAnswer: 1,
        explanation: "Siddhartha Gautama nació alrededor del 563 a.C. en el reino de Shakya.",
      },
      {
        question: "¿A qué edad abandonó Siddhartha el palacio?",
        options: ["25 años", "29 años", "35 años", "40 años"],
        correctAnswer: 1,
        explanation: "Siddhartha abandonó el palacio a los 29 años después de descubrir el sufrimiento humano.",
      },
      {
        question: "¿Cuál es el nombre del árbol bajo el cual Buda alcanzó la iluminación?",
        options: ["Árbol de la Vida", "Árbol Bodhi", "Árbol Sagrado", "Árbol de la Sabiduría"],
        correctAnswer: 1,
        explanation: "Buda alcanzó la iluminación meditando bajo el árbol Bodhi en Gaya.",
      },
      {
        question: "¿Cuántos días meditó Buda antes de alcanzar la iluminación?",
        options: ["40 días", "49 días", "50 días", "60 días"],
        correctAnswer: 1,
        explanation: "Buda meditó durante 49 días bajo el árbol Bodhi antes de alcanzar la iluminación.",
      },
      {
        question: "¿Cuáles son las Cuatro Nobles Verdades de Buda?",
        options: ["Sobre el karma", "Sobre la reencarnación", "Sobre el sufrimiento, su causa, su fin y el camino", "Sobre la meditación"],
        correctAnswer: 2,
        explanation: "Las Cuatro Nobles Verdades son: la existencia del sufrimiento, la causa del sufrimiento, el fin del sufrimiento y el camino hacia el fin del sufrimiento.",
      },
    ],
  },
  {
    id: "cleopatra",
    title: "CLEOPATRA — LA ÚLTIMA REINA DE EGIPTO",
    shortTitle: "Cleopatra",
    year: "69-30 a.C.",
    location: "Egipto",
    description: "La faraona que desafió a Roma con inteligencia y belleza",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/cleopatra-hero_e5f4d17e.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/cleopatra-hero_e5f4d17e.jpg",
    sections: [
      {
        title: "La Última de los Ptolomeos",
        content: "Cleopatra VII nació el 69 a.C. en Alejandría, Egipto. Era miembro de la dinastía ptolemaica, una familia griega que gobernaba Egipto desde la época de Alejandro Magno. Su padre, Ptolomeo XII, fue un gobernante débil que dejó el reino en caos.",
      },
      {
        title: "La Lucha por el Poder",
        content: "A los 21 años, Cleopatra fue exiliada por su hermano Ptolomeo XIII. Se alió con Julio César, quien la ayudó a recuperar el trono. Su relación con César fue tanto política como romántica, y tuvieron un hijo juntos, Cesarión.",
      },
      {
        title: "El Romance con Marco Antonio",
        content: "Después de la muerte de César, Cleopatra se alió con Marco Antonio, uno de los triunviros de Roma. Su romance fue legendario, y juntos tuvieron tres hijos. Cleopatra usó su inteligencia y carisma para mantener a Egipto independiente en un mundo dominado por Roma.",
      },
      {
        title: "La Batalla de Actium",
        content: "En el 31 a.C., Marco Antonio y Cleopatra fueron derrotados por Octaviano (futuro Augusto) en la Batalla de Actium. Esta derrota marcó el fin del poder de Cleopatra. Octaviano persiguió a los amantes hasta Alejandría.",
      },
      {
        title: "El Final de una Era",
        content: "Enfrentada a la captura y la humillación, Cleopatra eligió la muerte. Según la leyenda, se suicidó con una serpiente venenosa (áspid). Con su muerte en el 30 a.C., Egipto se convirtió en una provincia romana, terminando 3,000 años de faraones independientes.",
      },
    ],
    quiz: [
      {
        question: "¿En qué año nació Cleopatra?",
        options: ["75 a.C.", "69 a.C.", "60 a.C.", "50 a.C."],
        correctAnswer: 1,
        explanation: "Cleopatra VII nació el 69 a.C. en Alejandría, Egipto.",
      },
      {
        question: "¿Con quién se alió Cleopatra para recuperar el trono?",
        options: ["Pompeyo", "Julio César", "Marco Antonio", "Octaviano"],
        correctAnswer: 1,
        explanation: "Cleopatra se alió con Julio César para recuperar el trono de su hermano.",
      },
      {
        question: "¿Cuál fue el nombre del hijo de Cleopatra y Julio César?",
        options: ["Ptolomeo", "Cesarión", "Alejandro", "Dionisio"],
        correctAnswer: 1,
        explanation: "Cesarión fue el hijo de Cleopatra y Julio César.",
      },
      {
        question: "¿En qué batalla fue derrotada Cleopatra por Octaviano?",
        options: ["Batalla del Nilo", "Batalla de Actium", "Batalla de Alejandría", "Batalla del Mediterráneo"],
        correctAnswer: 1,
        explanation: "Cleopatra y Marco Antonio fueron derrotados por Octaviano en la Batalla de Actium en el 31 a.C.",
      },
      {
        question: "¿En qué año murió Cleopatra?",
        options: ["35 a.C.", "32 a.C.", "30 a.C.", "25 a.C."],
        correctAnswer: 2,
        explanation: "Cleopatra murió en el 30 a.C., marcando el fin de la dinastía ptolemaica y la independencia de Egipto.",
      },
    ],
  },
  {
    id: "templars",
    title: "TEMPLARIOS — LOS CABALLEROS DE LA CRUZ",
    shortTitle: "Templarios",
    year: "1119-1312 d.C.",
    location: "Tierra Santa y Europa",
    description: "La orden militar más poderosa de la Edad Media",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/templars-hero_19b2067f.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/templars-hero_19b2067f.jpg",
    sections: [
      {
        title: "El Nacimiento de la Orden",
        content: "La Orden del Temple fue fundada alrededor de 1119 por Hugo de Payens y otros caballeros franceses. Su propósito original era proteger a los peregrinos cristianos que viajaban a Jerusalén después de la Primera Cruzada. Recibieron el reconocimiento papal en 1129.",
      },
      {
        title: "Los Guardianes de Tierra Santa",
        content: "Los Templarios se convirtieron en los defensores de los reinos cristianos en Tierra Santa. Construyeron fortalezas, participaron en batallas contra los musulmanes y ganaron una reputación de guerreros valientes e implacables. Su distintivo uniforme blanco con una cruz roja los hacía reconocibles en todo el mundo.",
      },
      {
        title: "Poder Económico y Político",
        content: "Además de ser guerreros, los Templarios se convirtieron en banqueros y prestamistas. Acumularon riquezas inmensas y desarrollaron una red de fortalezas y comanderías en toda Europa. Su poder económico rivalizaba con el de los reinos europeos.",
      },
      {
        title: "La Caída de Acre",
        content: "En 1291, la ciudad de Acre, el último bastión cristiano en Tierra Santa, cayó ante los musulmanes. Esta derrota marcó el fin efectivo de la presencia militar templaria en Oriente Medio. Los Templarios se retiraron a su fortaleza en Chipre.",
      },
      {
        title: "La Supresión de la Orden",
        content: "En 1312, el Papa Clemente V disolvió la Orden del Temple bajo presión del rey Felipe IV de Francia, quien codiciaba sus riquezas. Muchos Templarios fueron arrestados, torturados y ejecutados. La orden que había dominado Europa durante casi 200 años fue erradicada.",
      },
    ],
    quiz: [
      {
        question: "¿En qué año fue fundada la Orden del Temple?",
        options: ["1100 d.C.", "1119 d.C.", "1140 d.C.", "1150 d.C."],
        correctAnswer: 1,
        explanation: "La Orden del Temple fue fundada alrededor de 1119 por Hugo de Payens.",
      },
      {
        question: "¿Cuál era el propósito original de los Templarios?",
        options: ["Conquistar Tierra Santa", "Proteger peregrinos", "Acumular riquezas", "Gobernar Europa"],
        correctAnswer: 1,
        explanation: "El propósito original de los Templarios era proteger a los peregrinos cristianos que viajaban a Jerusalén.",
      },
      {
        question: "¿Cuál era el distintivo uniforme de los Templarios?",
        options: ["Negro con cruz blanca", "Blanco con cruz roja", "Rojo con cruz blanca", "Gris con cruz negra"],
        correctAnswer: 1,
        explanation: "Los Templarios usaban un uniforme blanco con una cruz roja, que los hacía reconocibles en todo el mundo.",
      },
      {
        question: "¿En qué año cayó Acre, el último bastión cristiano en Tierra Santa?",
        options: ["1270 d.C.", "1280 d.C.", "1291 d.C.", "1300 d.C."],
        correctAnswer: 2,
        explanation: "Acre cayó en 1291, marcando el fin efectivo de la presencia militar templaria en Oriente Medio.",
      },
      {
        question: "¿En qué año fue disuelta la Orden del Temple?",
        options: ["1300 d.C.", "1310 d.C.", "1312 d.C.", "1320 d.C."],
        correctAnswer: 2,
        explanation: "La Orden del Temple fue disuelta en 1312 por el Papa Clemente V.",
      },
    ],
  },
  {
    id: "don-carlos",
    title: "EL PRÍNCIPE DON CARLOS — UN DESTINO TRÁGICO",
    shortTitle: "Don Carlos",
    year: "1545-1568 d.C.",
    location: "España",
    description: "El heredero cuya locura selló su destino",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/don-carlos-hero_7fdff512.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/don-carlos-hero_7fdff512.jpg",
    sections: [
      {
        title: "El Príncipe de Asturias",
        content: "Don Carlos nació el 8 de julio de 1545 en Valladolid, España. Era el hijo primogénito del rey Felipe II, lo que lo convertía en heredero de la Monarquía Hispánica. Su educación fue rigurosa, preparándolo para gobernar el imperio más poderoso de Europa.",
      },
      {
        title: "El Accidente Fatídico",
        content: "En 1562, a los 17 años, Don Carlos sufrió un grave accidente. Cayó por las escaleras de su residencia en Alcalá mientras perseguía a una criada. El golpe en la cabeza fue severo, requiriendo una trepanación (cirugía cerebral). Después del accidente, su comportamiento cambió drásticamente.",
      },
      {
        title: "La Locura Creciente",
        content: "Después del accidente, Don Carlos mostró signos de inestabilidad mental. Tenía arrebatos de violencia, paranoia y comportamiento errático. Sus médicos no podían determinar si su condición era resultado del accidente cerebral o de una enfermedad mental preexistente.",
      },
      {
        title: "La Conspiración Contra el Rey",
        content: "En 1568, Don Carlos fue acusado de conspirar contra su padre, el rey Felipe II. Supuestamente, planeaba huir a Flandes y liderar una rebelión. Felipe II, temeroso de que su hijo inestable pudiera poner en peligro el imperio, lo encarceló en el Alcázar de Segovia.",
      },
      {
        title: "La Muerte en Prisión",
        content: "Don Carlos murió en prisión el 24 de julio de 1568, apenas seis meses después de su encarcelamiento. Las circunstancias exactas de su muerte permanecen misteriosas. Algunos historiadores sugieren que murió de cólico, otros de envenenamiento. Su muerte marcó el fin de una tragedia personal y política.",
      },
    ],
    quiz: [
      {
        question: "¿En qué año nació Don Carlos?",
        options: ["1540 d.C.", "1543 d.C.", "1545 d.C.", "1548 d.C."],
        correctAnswer: 2,
        explanation: "Don Carlos nació el 8 de julio de 1545 en Valladolid, España.",
      },
      {
        question: "¿Qué accidente sufrió Don Carlos en 1562?",
        options: ["Caída de caballo", "Caída por escaleras", "Accidente de carruaje", "Herida de espada"],
        correctAnswer: 1,
        explanation: "Don Carlos cayó por las escaleras de su residencia en Alcalá en 1562, sufriendo un grave golpe en la cabeza.",
      },
      {
        question: "¿Quién fue el padre de Don Carlos?",
        options: ["Carlos V", "Felipe II", "Felipe III", "Enrique VIII"],
        correctAnswer: 1,
        explanation: "Felipe II fue el padre de Don Carlos y rey de España.",
      },
      {
        question: "¿Dónde fue encarcelado Don Carlos?",
        options: ["Torre de Londres", "Alcázar de Segovia", "Castillo de Burgos", "Palacio Real de Madrid"],
        correctAnswer: 1,
        explanation: "Don Carlos fue encarcelado en el Alcázar de Segovia en 1568.",
      },
      {
        question: "¿En qué año murió Don Carlos?",
        options: ["1565 d.C.", "1566 d.C.", "1567 d.C.", "1568 d.C."],
        correctAnswer: 3,
        explanation: "Don Carlos murió el 24 de julio de 1568, apenas seis meses después de su encarcelamiento.",
      },
    ],
  },
  {
    id: "caligula",
    title: "CALÍGULA — LOCURA Y PODER",
    shortTitle: "Calígula",
    year: "12-41 d.C.",
    location: "Imperio Romano",
    description: "El emperador cuya locura llevó a Roma al borde del caos",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/caligula-hero_b34d7f10.jpg",
    heroImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663530602239/k3GEbN7yfwzPuP9eMV9DCJ/caligula-hero_b34d7f10.jpg",
    sections: [
      {
        title: "El Niño Emperador",
        content: "Calígula nació el 31 de agosto del 12 d.C. como Gayo Julio César Augusto Germánico. Su apodo 'Calígula' significa 'botitas', derivado de las pequeñas sandalias militares que usaba de niño. Era el hijo del popular general Germánico, lo que le daba una base de apoyo entre el pueblo y el ejército.",
      },
      {
        title: "El Ascenso al Poder",
        content: "Calígula se convirtió en emperador a los 24 años después de la muerte de Tiberio en el 37 d.C. Inicialmente, fue popular entre el pueblo romano. Redujo impuestos, liberó prisioneros políticos y realizó actos de generosidad. Sin embargo, esta fase de popularidad fue breve.",
      },
      {
        title: "El Cambio Radical",
        content: "Después de una enfermedad grave en el 37 d.C., Calígula cambió drásticamente. Algunos historiadores sugieren que sufrió una enfermedad mental o envenenamiento. Otros creen que simplemente reveló su verdadera naturaleza. Su reinado se convirtió en un régimen de terror.",
      },
      {
        title: "La Tiranía y la Locura",
        content: "Calígula ejecutó a miembros de su propia familia, incluyendo a su primo Tiberio Gémelo. Ordenó la muerte de senadores, generales y ciudadanos prominentes. Gastó las riquezas del imperio en construcciones extravagantes y entretenimientos. Su paranoia y crueldad no tenían límites.",
      },
      {
        title: "El Fin de un Tirano",
        content: "Después de solo cuatro años de reinado, Calígula fue asesinado el 24 de enero del 41 d.C. por miembros de la Guardia Pretoriana. Su muerte fue celebrada por el Senado y el pueblo romano. Su reinado breve pero brutal dejó cicatrices en Roma que tardarían años en sanar.",
      },
    ],
    quiz: [
      {
        question: "¿En qué año nació Calígula?",
        options: ["10 d.C.", "12 d.C.", "15 d.C.", "18 d.C."],
        correctAnswer: 1,
        explanation: "Calígula nació el 31 de agosto del 12 d.C.",
      },
      {
        question: "¿Qué significa el apodo 'Calígula'?",
        options: ["Pequeño soldado", "Botitas", "Pequeño emperador", "Guerrero"],
        correctAnswer: 1,
        explanation: "'Calígula' significa 'botitas', derivado de las pequeñas sandalias militares que usaba de niño.",
      },
      {
        question: "¿A qué edad se convirtió Calígula en emperador?",
        options: ["20 años", "22 años", "24 años", "26 años"],
        correctAnswer: 2,
        explanation: "Calígula se convirtió en emperador a los 24 años en el 37 d.C.",
      },
      {
        question: "¿Quién fue el emperador anterior a Calígula?",
        options: ["Augusto", "Tiberio", "Claudio", "Nerón"],
        correctAnswer: 1,
        explanation: "Tiberio fue el emperador anterior a Calígula. Murió en el 37 d.C.",
      },
      {
        question: "¿En qué año fue asesinado Calígula?",
        options: ["38 d.C.", "39 d.C.", "40 d.C.", "41 d.C."],
        correctAnswer: 3,
        explanation: "Calígula fue asesinado el 24 de enero del 41 d.C. por miembros de la Guardia Pretoriana.",
      },
    ],
  },
];
